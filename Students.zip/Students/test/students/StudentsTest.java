package students;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;

public class StudentsTest {
    private Students students;

    @Before
    public void setUp() {
        students = new Students();
    }

    @Test
    public void testSaveStudent() {
        students.saveStudent("S001", "John Doe", "john.doe@example.com", "Mathematics", 20);
        ArrayList<Student> studentList = students.getStudents();
        assertEquals("S001", studentList.get(0).getStudentId());
        assertEquals("John Doe", studentList.get(0).getStudentName());
        assertEquals("john.doe@example.com", studentList.get(0).getStudentEmail());
        assertEquals("Mathematics", studentList.get(0).getStudentCourse());
        assertEquals(20, studentList.get(0).getStudentAge());
    }

    @Test
    public void testSearchStudent() {
        students.saveStudent("S001", "John Doe", "john.doe@example.com", "Mathematics", 20);
        Student foundStudent = students.searchStudent("S001");
        assertNotNull(foundStudent);
        assertEquals("S001", foundStudent.getStudentId());
        assertEquals("John Doe", foundStudent.getStudentName());
        assertEquals("john.doe@example.com", foundStudent.getStudentEmail());
        assertEquals("Mathematics", foundStudent.getStudentCourse());
        assertEquals(20, foundStudent.getStudentAge());
    }
    
     @Test
    public void testSearchStudent_StudentNotFound() {
        Student foundStudent = students.searchStudent("S999");
        assertNull(foundStudent);
    }

    @Test
    public void testStudentNotFound() {
        Student foundStudent = students.searchStudent("S999");
        assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        students.saveStudent("S001", "John Doe", "john.doe@example.com", "Mathematics", 20);
        students.deleteStudent();
        ArrayList<Student> studentList = students.getStudents();
        assertTrue(studentList.isEmpty());
    }

    @Test
    public void testPrintStudentReport() {
        students.saveStudent("S001", "John Doe", "john.doe@example.com", "Mathematics", 20);
    }
    
     @Test
    public void testStudentAge_StudentAgeValid() {
        Student student = new Student("S002", "Jane Doe", "jane.doe@example.com", "Science", 18);
        assertEquals(18, student.getStudentAge());
    }
}

//Title: PROG6112 REPO - PROG6112 ASSIGNMENT SUPPORT
//Author: Denzyl Govender
//Date:03 September 2024
//Version: 1
//Available: https://github.com/VCDN-2024/PROG6112-REPO

