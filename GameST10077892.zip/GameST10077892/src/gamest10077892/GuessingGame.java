package gamest10077892;

// The GuessingGame class extends the Game class and provides functionality for a number guessing game.
class GuessingGame extends Game {

    // Constructor initializes the game with the maximum number of attempts and the number to guess.
    public GuessingGame(int maxAttempts, int numberToGuess) {
        super(maxAttempts, numberToGuess);
    }

    // Method to start and manage the guessing game.
    public void playGame() {
        // Create a Scanner object for user input.
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        
        // Variable to track if the number has been guessed correctly.
        boolean isGuessed = false;

        // Loop until the user runs out of attempts or guesses the number correctly.
        while (attemptCount < maxAttempts && !isGuessed) {
            // Prompt the user to enter their guess.
            System.out.println("Enter your guess: ");
            
            // Read the user's guess from the console.
            int guess = scanner.nextInt();
            
            // Check if the user's guess is correct.
            isGuessed = makeAttempt(guess);

            // Provide feedback based on the user's guess.
            if (isGuessed) {
                System.out.println("Congratulations! You've guessed the number.");
            } else if (guess < numberToGuess) {
                System.out.println("The number is higher.");
            } else {
                System.out.println("The number is lower.");
            }
        }

        // If the number was not guessed within the allowed attempts, inform the user.
        if (!isGuessed) {
            System.out.println("Sorry, you've used all attempts. The number was " + numberToGuess);
        }

        // Display the final report of the game.
        showReport();
    }
}

//Title: Number guessing game using javascript
//Author: Geeks for geeks
//Date:03 September 2024
//Version: 1
//Available:https://www.geeksforgeeks.org/number-guessing-game-using-javascript/