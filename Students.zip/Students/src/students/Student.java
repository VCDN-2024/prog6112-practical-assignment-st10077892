package students;

public class Student {

    // Static method stub for saving a student; currently not implemented
    static void saveStudent(String s001, String john_Doe, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Method not yet implemented
    }
    
    // Instance variables for storing student details
    private String studentId;
    private String studentName;
    private String studentEmail;
    private String studentCourse;
    private int studentAge;
    
    // Constructor to initialize a new Student object with provided details
    public Student(String studentId, String studentName, String studentEmail, String studentCourse, int studentAge) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentCourse = studentCourse;
        this.studentAge = studentAge;
    }

    // Default constructor; throws exception if used (not supported)
    Student() {
        throw new UnsupportedOperationException("Not supported yet."); // Constructor not yet implemented
    }
    
    // Getter for student ID
    public String getStudentId() {
        return studentId;
    }

    // Setter for student ID
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    // Getter for student name
    public String getStudentName() {
        return studentName;
    }

    // Setter for student name
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    
    // Getter for student email
    public String getStudentEmail() {
        return studentEmail;
    }

    // Setter for student email
    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    // Getter for student course
    public String getStudentCourse() {
        return studentCourse;
    }

    // Setter for student course
    public void setStudentCourse(String studentCourse) {
        this.studentCourse = studentCourse;
    }

    // Getter for student age
    public int getStudentAge() {
        return studentAge;
    }

    // Setter for student age
    public void setStudentAge(int studentAge) {
        this.studentAge = studentAge;
    }

    // Override toString method to provide a string representation of the student
    @Override
    public String toString() {
        // Concatenate and return a string with all student details
        return "Student ID: " + studentId + ", Name: " + studentName + ", Email: " + studentEmail + ", Course: " + studentCourse + ", Age: " + studentAge;
    }
}


//Title: PROG6112 REPO - PROG6112 ASSIGNMENT SUPPORT
//Author: Denzyl Govender
//Date:03 September 2024
//Version: 1
//Available: https://github.com/VCDN-2024/PROG6112-REPO

