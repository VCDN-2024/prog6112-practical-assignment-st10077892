package gamest10077892;

/**
 * The Game class represents a basic guessing game where players have a limited number of attempts
 * to guess a predetermined number. It tracks the number of attempts made, the guesses, and provides
 * a report of the game results.
 */
class Game {
    // The maximum number of attempts allowed in the game.
    protected int maxAttempts;
    
    // Array to store the guesses made by the player.
    protected int[] attempts;
    
    // The number that the player needs to guess.
    protected int numberToGuess;
    
    // The number of attempts made so far.
    protected int attemptCount;

    /**
     * Constructor to initialize the game with a maximum number of attempts and the number to guess.
     * 
     * @param maxAttempts The maximum number of attempts allowed in the game.
     * @param numberToGuess The number that the player needs to guess.
     */
    public Game(int maxAttempts, int numberToGuess) {
        this.maxAttempts = maxAttempts;
        this.numberToGuess = numberToGuess;
        this.attempts = new int[maxAttempts];
        this.attemptCount = 0;
    }

    /**
     * Makes an attempt to guess the number. If the guess is correct, returns true; otherwise, false.
     * 
     * @param guess The number guessed by the player.
     * @return true if the guess is correct, false otherwise.
     */
    public boolean makeAttempt(int guess) {
        if (attemptCount < maxAttempts) {
            attempts[attemptCount++] = guess;
            return guess == numberToGuess;
        }
        return false;
    }

    /**
     * Displays a report of the game, including the number to guess, the total attempts made,
     * and a list of all attempts.
     */
    public void showReport() {
        System.out.println("Game Report:");
        System.out.println("Number to Guess: " + numberToGuess);
        System.out.println("Attempts Made: " + attemptCount);
        System.out.println("Attempts:");
        for (int i = 0; i < attemptCount; i++) {
            System.out.println("Attempt " + (i + 1) + ": " + attempts[i]);
        }
    }
}

//Title: Number guessing game using javascript
//Author: Geeks for geeks
//Date:03 September 2024
//Version: 1
//Available:https://www.geeksforgeeks.org/number-guessing-game-using-javascript/

