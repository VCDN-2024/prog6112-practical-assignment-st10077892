package students;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Students {
    // List to hold student objects
    private ArrayList<Student> students;
    // Scanner object for user input
    private Scanner scanner;
    
    // Constructor initializes the students list and scanner
    public Students(){
        students = new ArrayList<>();
        scanner = new Scanner(System.in);
    }
    
    // Method to save a new student entered by the user
    public void saveStudent() {
        scanner.nextLine(); // Consume newline
        System.out.print("Enter student ID: ");
        String studentId = scanner.nextLine();
        System.out.print("Enter student Name: ");
        String studentName = scanner.nextLine();
        System.out.print("Enter Student Email: ");
        String studentEmail = scanner.nextLine();
        System.out.print("Enter Student Course: ");
        String studentCourse = scanner.nextLine();
        
        int studentAge = 0;
        boolean validInput = false;
        
        // Loop to validate student age
        while (!validInput){
            System.out.print("Enter Students Age: ");
            try {
                studentAge = scanner.nextInt();
                if (studentAge < 16) {
                    System.out.println("You have entered an incorrect student age!!!. Please re-enter the student age.");
                } else {
                    validInput = true;
                }
            } catch (InputMismatchException e) {
                // Handle invalid input
                System.out.println("Invalid input. Please enter a numeric value for quantity.");
                scanner.next(); // Consume invalid input
            }
        }
        
        // Create a new Student object and add it to the list
        Student newStudent = new Student(studentId, studentName, studentEmail, studentCourse, studentAge);
        students.add(newStudent);
        System.out.println("New Student Successfully Saved");
    }
    
    // Method to save a new student with provided parameters
    public void saveStudent(String studentId, String studentName, String studentEmail, String studentCourse, int studentAge) {
        // Create a new Student object and add it to the list
        Student newStudent = new Student(studentId, studentName, studentEmail, studentCourse, studentAge);
        students.add(newStudent);
        System.out.println("Student saved successfully.");
    }
        
    // Method to search for a student by ID
    public Student searchStudent(String studentId) {
        for (Student student : students) {
            if (student.getStudentId().equalsIgnoreCase(studentId)) {
                return student;  
            }
        }
        return null; // Return null if student is not found
    }
        
    // Method to delete a student by ID
    public void deleteStudent(String s001, String y) {
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Student ID to delete: ");
        String StudentId = scanner.nextLine();
        boolean found = false;

        for (Student student : students) {
            if (student.getStudentId().equalsIgnoreCase(StudentId)) {
                System.out.print("Are you sure you want to delete this student? (y/n): ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student);
                    System.out.println("Student deleted successfully.");
                } else {
                    System.out.println("Deletion canceled.");
                }
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found.");
        }
    }
         
    // Method to print a report of all students
    public void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
        } else {
            System.out.println("\nStudent Report:");
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }
          
    // Method to exit the application
    public void exitApplication() {
        System.out.println("Exiting application. Goodbye!");
    }

    // Getter for the students list
    public ArrayList<Student> getStudents() {
        return students;
    }
    
    // Method to display a menu and handle user choices
    public void launchMenu() {
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Save a new student");
            System.out.println("2. Search for a student");
            System.out.println("3. Delete a student");
            System.out.println("4. Print student report");
            System.out.println("5. Exit application");
            System.out.print("Enter your choice: ");
            
            int choice;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Exiting application.");
                break;
            }

            switch (choice) {
                case 1:
                    saveStudent(); // Call method to save a new student
                    break;
                case 2:
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Student ID to search: ");
                    String searchId = scanner.nextLine();
                    Student foundStudent = searchStudent(searchId);
                    if (foundStudent != null) {
                        System.out.println("Student found: " + foundStudent);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case 3:
                    deleteStudent("S001", "y"); // Call method to delete a student
                    break;
                case 4:
                    printStudentReport(); // Call method to print student report
                    break;
                case 5:
                    exitApplication(); // Call method to exit application
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }
    
    // Main method to start the application
    public static void main(String[] args) {
        Students students  = new Students();
        System.out.print("Press 1 to launch menu, any other key to exit: ");
        Scanner input = new Scanner(System.in);
        String choice = input.nextLine();

        if (choice.equals("1")) {
            students.launchMenu(); // Launch the menu if user presses 1
        } else {
            System.out.println("Exiting application. Goodbye!");
        }
    }
}


//Title: PROG6112 REPO - PROG6112 ASSIGNMENT SUPPORT
//Author: Denzyl Govender
//Date:03 September 2024
//Version: 1
//Available: https://github.com/VCDN-2024/PROG6112-REPO

