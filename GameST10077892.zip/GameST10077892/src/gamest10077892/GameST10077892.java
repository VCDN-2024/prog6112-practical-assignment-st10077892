package gamest10077892;

/**
 * The GameST10077892 class serves as the entry point for the game application.
 * It initializes a GuessingGame instance with a maximum number of attempts and 
 * a random target number between 1 and 100, then starts the game by calling
 * the playGame method.
 */

public class GameST10077892 {
    public static void main(String[] args) {
        GuessingGame game = new GuessingGame(5, (int) (Math.random() * 100) + 1);
        game.playGame();
    }
}

//Title: Number guessing game using javascript
//Author: Geeks for geeks
//Date:03 September 2024
//Version: 1
//Available:https://www.geeksforgeeks.org/number-guessing-game-using-javascript/

